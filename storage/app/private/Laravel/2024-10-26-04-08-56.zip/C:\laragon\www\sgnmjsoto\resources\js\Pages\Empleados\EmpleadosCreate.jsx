import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm } from '@inertiajs/react';
import { useEffect } from 'react';

export default function EmpleadosCreate() {
    const { data, setData, post, processing, errors } = useForm({
        nombre: '',
        apellido: '',
        cedula: '',
        centro_pago: '',
        fecha_ingreso: '',
        tipo_personal: '',
        cargo: '',
    });

    const submit = (e) => {
        e.preventDefault();
        post(route('empleados.store'));
    };

    const handleNombreApellidoChange = (e, field) => {
        // Expresión regular para permitir solo letras, acentos, espacios y la ñ
        const regex = /^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]*$/;
        if (regex.test(e.target.value) || e.target.value === '') {
            setData(field, e.target.value);
        }
    };

    const handleCedulaChange = (e) => {
        // Permitir solo números
        const regex = /^[0-9]*$/;
        if (regex.test(e.target.value) || e.target.value === '') {
            setData('cedula', e.target.value);
        }
    };

    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold leading-tight text-gray-800">Crear Empleado</h2>}
        >
            <Head title="Crear Empleado" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <form onSubmit={submit}>
                                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                                    <div>
                                        <label className="block text-gray-700">Nombre</label>
                                        <input
                                            type="text"
                                            value={data.nombre}
                                            onChange={e => handleNombreApellidoChange(e, 'nombre')}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                        {errors.nombre && <p className="text-sm text-red-600">{errors.nombre}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700">Apellido</label>
                                        <input
                                            type="text"
                                            value={data.apellido}
                                            onChange={e => handleNombreApellidoChange(e, 'apellido')}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                        {errors.apellido && <p className="text-sm text-red-600">{errors.apellido}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700">Cédula</label>
                                        <input
                                            type="text"
                                            value={data.cedula}
                                            onChange={handleCedulaChange}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                        {errors.cedula && <p className="text-sm text-red-600">{errors.cedula}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700">Centro de Pago</label>
                                        <select
                                            value={data.centro_pago}
                                            onChange={e => setData('centro_pago', e.target.value)}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        >
                                            <option value="">Seleccione un banco</option>
                                            <option value="Banco de Venezuela">Banco de Venezuela</option>
                                            <option value="Bancamiga">Bancamiga</option>
                                            <option value="Banco Nacional de Crédito">Banco Nacional de Crédito</option>
                                            <option value="Banco Exterior">Banco Exterior</option>
                                            {/* Agrega más bancos según sea necesario */}
                                        </select>
                                        {errors.centro_pago && <p className="text-sm text-red-600">{errors.centro_pago}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700">Fecha de Ingreso</label>
                                        <input
                                            type="date"
                                            value={data.fecha_ingreso}
                                            onChange={e => setData('fecha_ingreso', e.target.value)}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                            required
                                        />
                                        {errors.fecha_ingreso && <p className="text-sm text-red-600">{errors.fecha_ingreso}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700">Tipo de Personal</label>
                                        <input
                                            type="text"
                                            value={data.tipo_personal}
                                            onChange={e => handleNombreApellidoChange(e, 'tipo_personal')}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                        {errors.tipo_personal && <p className="text-sm text-red-600">{errors.tipo_personal}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-gray-700">Cargo</label>
                                        <input
                                            type="text"
                                            value={data.cargo}
                                            onChange={e => handleNombreApellidoChange(e, 'cargo')}
                                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        />
                                        {errors.cargo && <p className="text-sm text-red-600">{errors.cargo}</p>}
                                    </div>
                                </div>

                                <div className="mt-6">
                                    <button type="button" onClick={() => window.history.back()} className="mr-2 px-4 py-2 text-white bg-gray-600 hover:bg-gray-700 rounded-md">
                                        Volver a Empleados
                                    </button>
                                    <button type="submit" className="px-4 py-2 text-white bg-blue-600 hover:bg-blue-700 rounded-md" disabled={processing}>
                                        Guardar
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
