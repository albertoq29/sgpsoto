<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class BackupController extends Controller
{
    // Listar todos los respaldos disponibles
    public function index()
    {
        $backups = Storage::disk('local')->files('backups'); // Cambia a tu carpeta de respaldos
        $formattedBackups = array_map(function ($file) {
            return [
                'id' => pathinfo($file, PATHINFO_FILENAME),
                'name' => pathinfo($file, PATHINFO_BASENAME),
                'created_at' => date("Y-m-d H:i:s", Storage::disk('local')->lastModified($file)),
            ];
        }, $backups);

        return inertia('Backup/Backups', ['backups' => $formattedBackups]);
    }

    // Crear un nuevo respaldo
    public function create()
    {
        // Aquí puedes agregar la lógica para crear un nuevo respaldo
        // Por ejemplo, ejecutando un comando para respaldar la base de datos
        
        $backupName = 'backup_' . date('Ymd_His') . '.sql';
        $path = storage_path("app/backups/{$backupName}");

        // Suponiendo que utilizas mysqldump para crear el respaldo
        $command = "mysqldump -u tu_usuario -p'tu_contraseña' tu_base_de_datos > $path";
        exec($command);

        return response()->json(['name' => $backupName, 'created_at' => now()]);
    }

    // Restaurar un respaldo específico
    public function restore($fileName)
    {
        $path = storage_path("app/backups/{$fileName}");

        if (!file_exists($path)) {
            return response()->json(['error' => 'Backup not found.'], 404);
        }

        $command = "mysql -u tu_usuario -p'tu_contraseña' tu_base_de_datos < $path";
        exec($command);

        return response()->json(['success' => 'Backup restored successfully.']);
    }
}
