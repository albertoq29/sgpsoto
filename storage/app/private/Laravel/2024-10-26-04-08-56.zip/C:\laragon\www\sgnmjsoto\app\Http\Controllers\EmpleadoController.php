<?php
namespace App\Http\Controllers;

use App\Models\Empleado;
use Illuminate\Http\Request;
use Inertia\Inertia;

class EmpleadoController extends Controller
{
    public function index()
    {
        $empleados = Empleado::all();
        return Inertia::render('Empleados/EmpleadosShow', [
            'empleados' => $empleados,
        ]);
    }

    public function create()
    {
        return Inertia::render('Empleados/EmpleadosCreate');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'apellido' => 'required|string|max:255',
            'cedula' => 'required|string|max:20|unique:empleados',
            'centro_pago' => 'required|string|max:255',
            'fecha_ingreso' => 'required|',
            'tipo_personal' => 'required|string|max:255',
            'cargo' => 'required|string|max:255',
        ]);

        Empleado::create($request->all());

        return redirect()->route('empleados.index')->with('success', 'Empleado creado exitosamente.');
    }

    public function edit($id)
    {
        $empleado = Empleado::findOrFail($id); // Busca al empleado por ID
        return Inertia::render('Empleados/EmpleadosEdit', [
            'empleado' => $empleado,
        ]);
    }

public function update(Request $request, $id)
{
    $request->validate([
        'nombre' => 'required|string|max:255',
        'apellido' => 'required|string|max:255',
        'cedula' => 'required|string|max:20|unique:empleados,cedula,' . $id,
        'centro_pago' => 'required|string|max:255',
        'fecha_ingreso' => 'required|',
        'tipo_personal' => 'required|string|max:255',
        'cargo' => 'required|string|max:255',
    ]);

    $empleado = Empleado::findOrFail($id); // Busca al empleado por ID
    $empleado->update($request->all()); // Actualiza los datos

    return redirect()->route('empleados.index')->with('success', 'Empleado actualizado exitosamente.');
}




public function destroy($id)
{
    // Busca el empleado por ID
    $empleado = Empleado::findOrFail($id);

    // Elimina el empleado
    $empleado->delete();

    // Redirige a la lista de empleados con un mensaje de éxito
    return redirect()->route('empleados.index')->with('success', 'Empleado eliminado correctamente.');
}

}
