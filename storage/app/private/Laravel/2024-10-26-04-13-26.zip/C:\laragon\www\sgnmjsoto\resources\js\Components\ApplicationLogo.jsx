export default function ApplicationLogo(props) {
    return (
        <div style={{ display: 'flex', justifyContent: 'center' }}>
            <img
                {...props}
                src="http://www.logobook.com/wp-content/uploads/2016/10/Museo_de_Arte_Moderno_Jesus_Soto_logo.svg"// aqui va el logo
                alt="Logo de la aplicación"
                style={{ width: '35%', height: 'auto' }} // Ajusta el tamaño según sea necesario
            />
        </div>
    );
}
