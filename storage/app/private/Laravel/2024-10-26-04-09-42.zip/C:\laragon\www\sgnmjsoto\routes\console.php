<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote')->hourly();

 function schedule(Schedule $schedule)
{
    $schedule->command('backup:run')->daily()->at('00:10'); // Realiza el respaldo diario a la 1 AM
}
