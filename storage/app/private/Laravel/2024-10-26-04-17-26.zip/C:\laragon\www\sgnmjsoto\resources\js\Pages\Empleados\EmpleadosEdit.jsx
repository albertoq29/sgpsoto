import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm } from '@inertiajs/react';
import { useState } from 'react';

export default function EmpleadosEdit({ empleado }) {
    const { data, setData, put, processing, errors } = useForm({
        nombre: empleado.nombre,
        apellido: empleado.apellido,
        cedula: empleado.cedula,
        centro_pago: empleado.centro_pago,
        fecha_ingreso: empleado.fecha_ingreso,
        tipo_personal: empleado.tipo_personal,
        cargo: empleado.cargo,
    });

    const submit = (e) => {
        e.preventDefault();
        put(route('empleados.update', empleado.id)); // Asegúrate de que el ID es correcto
    };

    const bancos = [
        "Banco de Venezuela",
        "Bancaribe",
        "Banesco",
        "Banco del Tesoro",
        "Banco Exterior",
        "Banco Provincial",
        "BBVA Provincial",
        "Banco Nacional de Crédito",
        "Banco Caroní",
        "Banco Agrícola de Venezuela",
        // ... añade más bancos según sea necesario
    ];

    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Editar Empleado
                </h2>
            }
        >
            <Head title="Editar Empleado" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <form onSubmit={submit}>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Nombre</label>
                                    <input
                                        type="text"
                                        value={data.nombre}
                                        onChange={e => setData('nombre', e.target.value)}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                        pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ\s]+"
                                        title="Solo se permiten letras, acentos, espacios y la letra 'ñ'."
                                    />
                                    {errors.nombre && <div className="text-red-500">{errors.nombre}</div>}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Apellido</label>
                                    <input
                                        type="text"
                                        value={data.apellido}
                                        onChange={e => setData('apellido', e.target.value)}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                        pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ\s]+"
                                        title="Solo se permiten letras, acentos, espacios y la letra 'ñ'."
                                    />
                                    {errors.apellido && <div className="text-red-500">{errors.apellido}</div>}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Cédula</label>
                                    <input
                                        type="text"
                                        value={data.cedula}
                                        onChange={e => setData('cedula', e.target.value.replace(/[^0-9]/g, ''))}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                        pattern="\d+"
                                        title="Solo se permiten números."
                                    />
                                    {errors.cedula && <div className="text-red-500">{errors.cedula}</div>}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Centro de Pago</label>
                                    <select
                                        value={data.centro_pago}
                                        onChange={e => setData('centro_pago', e.target.value)}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                    >
                                        <option value="" disabled>Seleccione un banco</option>
                                        {bancos.map((banco, index) => (
                                            <option key={index} value={banco}>{banco}</option>
                                        ))}
                                    </select>
                                    {errors.centro_pago && <div className="text-red-500">{errors.centro_pago}</div>}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Fecha de Ingreso</label>
                                    <input
                                        type="date"
                                        value={data.fecha_ingreso}
                                        onChange={e => setData('fecha_ingreso', e.target.value)}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                    />
                                    {errors.fecha_ingreso && <div className="text-red-500">{errors.fecha_ingreso}</div>}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Tipo de Personal</label>
                                    <input
                                        type="text"
                                        value={data.tipo_personal}
                                        onChange={e => setData('tipo_personal', e.target.value)}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                        pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ\s]+"
                                        title="Solo se permiten letras, acentos, espacios y la letra 'ñ'."
                                    />
                                    {errors.tipo_personal && <div className="text-red-500">{errors.tipo_personal}</div>}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Cargo</label>
                                    <input
                                        type="text"
                                        value={data.cargo}
                                        onChange={e => setData('cargo', e.target.value)}
                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                                        required
                                        pattern="[A-Za-zÑñáéíóúÁÉÍÓÚ\s]+"
                                        title="Solo se permiten letras, acentos, espacios y la letra 'ñ'."
                                    />
                                    {errors.cargo && <div className="text-red-500">{errors.cargo}</div>}
                                </div>

                                <div className="flex justify-end mt-4">
                                    <button
                                        type="submit"
                                        className="px-4 py-2 text-white bg-blue-600 hover:bg-blue-700 rounded-md"
                                        disabled={processing}
                                    >
                                        Actualizar Empleado
                                    </button>
                                    <a href={route('empleados.index')} className="ml-2 px-4 py-2 text-white bg-gray-600 hover:bg-gray-700 rounded-md">
                                        Volver a Empleados
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
