import { useRef, useState } from 'react';
import DangerButton from '@/Components/DangerButton';
import InputError from '@/Components/InputError';
import InputLabel from '@/Components/InputLabel';
import Modal from '@/Components/Modal';
import SecondaryButton from '@/Components/SecondaryButton';
import TextInput from '@/Components/TextInput';
import { useForm } from '@inertiajs/react';

export default function DeleteUserForm({ className = '' }) {
    const [confirmingUserDeletion, setConfirmingUserDeletion] = useState(false);
    const [showInstructions, setShowInstructions] = useState(false);
    const passwordInput = useRef();

    const {
        data,
        setData,
        delete: destroy,
        processing,
        reset,
        errors,
    } = useForm({
        password: '',
    });

    const confirmUserDeletion = () => {
        setConfirmingUserDeletion(true);
    };

    const deleteUser = (e) => {
        e.preventDefault();

        destroy(route('profile.destroy'), {
            preserveScroll: true,
            onSuccess: () => closeModal(),
            onError: () => passwordInput.current.focus(),
            onFinish: () => reset(),
        });
    };

    const closeModal = () => {
        setConfirmingUserDeletion(false);
        reset();
    };

    const toggleInstructions = () => {
        setShowInstructions(!showInstructions);
    };

    return (
        <section className={`space-y-6 ${className}`}>
            <header>
                <h2 className="text-lg font-medium text-gray-900">Eliminar Cuenta</h2>
                <p className="mt-1 text-sm text-gray-600">
                    Si ha decidido dejar la institución y desea borrar todos sus datos de nuestro sistema SGCOMCAR, le informamos que estamos comprometidos con la protección de su información personal y facilitaremos el proceso para garantizar su tranquilidad.
                </p>
                <button
                    className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                    onClick={toggleInstructions}
                >
                    Ver Instrucciones
                </button>
            </header>

            <Modal show={confirmingUserDeletion} onClose={closeModal}>
                <form onSubmit={deleteUser} className="p-6">
                    <h2 className="text-lg font-medium text-gray-900">
                        ¿Estás seguro de que deseas eliminar tu cuenta?
                    </h2>
                    <p className="mt-1 text-sm text-gray-600">
                        Una vez que se elimina tu cuenta, todos sus recursos y datos se borrarán permanentemente. Por favor, ingresa tu contraseña para confirmar que deseas eliminar tu cuenta permanentemente.
                    </p>
                    <div className="mt-6">
                        <InputLabel htmlFor="password" value="Contraseña" className="sr-only" />
                        <TextInput
                            id="password"
                            type="password"
                            name="password"
                            ref={passwordInput}
                            value={data.password}
                            onChange={(e) => setData('password', e.target.value)}
                            className="mt-1 block w-3/4"
                            isFocused
                            placeholder="Contraseña"
                        />
                        <InputError message={errors.password} className="mt-2" />
                    </div>
                    <div className="mt-6 flex justify-end">
                        <SecondaryButton onClick={closeModal}>Cancelar</SecondaryButton>
                        <DangerButton className="ms-3" disabled={processing}>
                            Eliminar Cuenta
                        </DangerButton>
                    </div>
                </form>
            </Modal>

            {showInstructions && (
                <div className="fixed inset-0 flex items-center justify-center z-50">
                    <div className="bg-black bg-opacity-50 absolute inset-0"></div>
                    <div className="bg-white p-8 rounded-lg shadow-lg transform transition-all duration-300 ease-out animate-fall">
                        <h3 className="text-lg font-medium text-gray-900">Instrucciones para Dejar la Institución y Borrar sus Datos de SGCOMCAR</h3>
                        <p className="mt-2 text-sm text-gray-600">
                            Estimado(a) usuario(a),
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            Si ha decidido dejar la institución y desea borrar todos sus datos de nuestro sistema SGCOMCAR, le informamos que estamos comprometidos con la protección de su información personal y facilitaremos el proceso para garantizar su tranquilidad.
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            Para proceder con la eliminación de sus datos de SGCOMCAR, por favor siga los siguientes pasos:
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            <strong>Contacto Inicial:</strong> Envíe un correo electrónico a nuestro equipo de soporte a la dirección <a href="mailto:sgcomcar@gmail.com" className="text-blue-500 underline">sgcomcar@gmail.com</a>. En el asunto del correo, indique "Solicitud de Eliminación de Datos".
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            <strong>Información Necesaria:</strong> En el cuerpo del correo, por favor incluya la siguiente información:
                            <ul className="list-disc list-inside">
                                <li>Su nombre completo.</li>
                                <li>Número de identificación o documento que utilizó para registrarse.</li>
                                <li>Una breve explicación del motivo por el cual desea eliminar sus datos.</li>
                            </ul>
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            <strong>Confirmación de Identidad:</strong> Para proteger su privacidad, es posible que le solicitemos información adicional o documentos que confirmen su identidad. Esto es una medida de seguridad para asegurarnos de que la solicitud proviene del titular de los datos.
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            <strong>Proceso de Eliminación:</strong> Una vez recibida y verificada su solicitud, nuestro equipo procederá a eliminar sus datos de nuestro sistema. Le notificaremos por correo electrónico cuando el proceso haya sido completado. Tenga en cuenta que este proceso puede tomar varios días hábiles.
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            <strong>Confirmación Final:</strong> Le enviaremos un correo de confirmación una vez que todos sus datos hayan sido eliminados de SGCOMCAR. En este correo, se le informará que su información ha sido completamente borrada y que ya no estará disponible en nuestros registros.
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            Nos comprometemos a manejar su solicitud con la mayor prontitud y confidencialidad. Si tiene alguna pregunta o necesita asistencia adicional durante este proceso, no dude en contactarnos a través de <a href="mailto:sgcomcar@gmail.com" className="text-blue-500 underline">sgcomcar@gmail.com</a>.
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            Agradecemos su comprensión y cooperación en este asunto.
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            Atentamente,
                        </p>
                        <p className="mt-2 text-sm text-gray-600">
                            <strong>El equipo de SGCOMCAR</strong>
                        </p>
                        <div className="mt-6 flex justify-end">
                            <button
                                className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                                onClick={toggleInstructions}
                            >
                                Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </section>
    );
}
