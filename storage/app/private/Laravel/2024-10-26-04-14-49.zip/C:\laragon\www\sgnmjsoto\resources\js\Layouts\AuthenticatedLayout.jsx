import { Link, usePage } from '@inertiajs/react';
import { useState } from 'react';

export default function Authenticated({ header, children }) {
    const user = usePage().props.auth.user;
    const [showSidebar, setShowSidebar] = useState(false);

    return (
        <div className="relative min-h-screen bg-gray-100">
            {/* Botón de 3 rayas para abrir el menú lateral */}
            <nav className="border-b border-gray-100 bg-white">
                <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                    <div className="flex h-16 justify-between">
                        <div className="-me-2 flex items-center">
                            <button
                                onClick={() => setShowSidebar(!showSidebar)}
                                className="inline-flex items-center justify-center rounded-md p-2 text-gray-400 transition duration-150 ease-in-out hover:bg-gray-100 hover:text-gray-500 focus:bg-gray-100 focus:text-gray-500 focus:outline-none"
                            >
                                <svg
                                    className="h-6 w-6"
                                    stroke="currentColor"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        className={ !showSidebar ? 'inline-flex' : 'hidden' }
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M4 6h16M4 12h16M4 18h16"
                                    />
                                    <path
                                        className={ showSidebar ? 'inline-flex' : 'hidden' }
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M6 18L18 6M6 6l12 12"
                                    />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            {/* Overlay que aparece cuando el menú está abierto */}
            {showSidebar && (
                <div
                    className="fixed inset-0 bg-gray-800 bg-opacity-50 z-20"
                    onClick={() => setShowSidebar(false)} // Cerrar el menú al hacer clic fuera
                ></div>
            )}

            {/* Menú lateral (Sidebar) */}
            <div
                className={`fixed top-0 left-0 w-64 h-full bg-white shadow-lg z-30 transform transition-transform duration-300 ease-in-out ${
                    showSidebar ? 'translate-x-0' : '-translate-x-full'
                }`}
            >
                <div className="p-4">
                    {/* Casilla con borde que encierra nombre, correo y botón de perfil */}
                    <div className="border rounded-lg p-4 mb-4">
                        <div className="text-base font-medium text-gray-800">
                            {user.name}
                        </div>
                        <div className="text-sm font-medium text-gray-500 mb-4">
                            {user.email}
                        </div>
                        <Link
                            href={route('profile.edit')}
                            className="block px-4 py-2 text-center text-white bg-blue-500 hover:bg-blue-600 rounded-md"
                        >
                            Perfil
                        </Link>
                    </div>

                    <nav className="space-y-4">
                        <Link
                            href={route('dashboard')}
                            className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                            Inicio
                        </Link>

                        {/* Mostrar el enlace de Empleados solo si el usuario tiene rol = 1 */}
                        {user.rol === 1 && (
                            <Link
                                href={route('empleados.index')}
                                className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                            >
                                Empleados
                            </Link>
                        )}

                        {/* Enlace a la vista de backups */}
                        <Link
                            href={route('backups.index')}
                            className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                            Backups
                        </Link>

                        <Link
                            href={route('logout')}
                            method="post"
                            as="button"
                            className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                        >
                            Cerrar sesión
                        </Link>
                    </nav>
                </div>
            </div>

            {/* Contenido principal */}
            <div className={`transition-all duration-300 ${showSidebar ? 'opacity-50' : 'opacity-100'}`}>
                {header && (
                    <header className="bg-white shadow">
                        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
                            {header}
                        </div>
                    </header>
                )}

                <main>{children}</main>
            </div>
        </div>
    );
}
