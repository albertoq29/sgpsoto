import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';

export default function EmpleadosShow({ empleados }) {
    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Empleados
                </h2>
            }
        >
            <Head title="Empleados" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <div className="flex justify-end mb-4">
                        <Link href={route('empleados.create')} className="px-4 py-2 text-white bg-green-600 hover:bg-green-700 rounded-md">
                            Crear Empleado
                        </Link>
                    </div>
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <div className="overflow-x-auto">
                                <table className="min-w-full bg-white border border-gray-200">
                                    <thead>
                                        <tr className="bg-gray-100">
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Nombre y Apellido</th>
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Cédula</th>
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Centro de Pago</th>
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Fecha de Ingreso</th>
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Tipo de Personal</th>
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Cargo</th>
                                            <th className="px-4 py-2 border-b text-left text-sm font-semibold text-gray-600">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {empleados.map((empleado) => (
                                            <tr key={empleado.id}>
                                                <td className="px-4 py-2 border-b">{empleado.nombre} {empleado.apellido}</td>
                                                <td className="px-4 py-2 border-b">{empleado.cedula}</td>
                                                <td className="px-4 py-2 border-b">{empleado.centro_pago}</td>
                                                <td className="px-4 py-2 border-b">{empleado.fecha_ingreso}</td>
                                                <td className="px-4 py-2 border-b">{empleado.tipo_personal}</td>
                                                <td className="px-4 py-2 border-b">{empleado.cargo}</td>
                                                <td className="px-4 py-2 border-b flex items-center space-x-4">
                                                    <Link href={route('empleados.edit', empleado.id)} className="text-blue-600 hover:text-blue-800 flex items-center">
                                                        <i className="fas fa-pencil-alt mr-1"></i> {/* Icono de lápiz */}
                                                        Editar
                                                    </Link>
                                                    <form action={route('empleados.destroy', empleado.id)} method="POST" className="inline">
                                                        <input type="hidden" name="_method" value="DELETE" />
                                                        <input type="hidden" name="_token" value={document.querySelector('meta[name="csrf-token"]').getAttribute('content')} />
                                                        <button 
                                                            type="submit" 
                                                            className="text-red-600 hover:text-red-800 flex items-center ml-4"
                                                            onClick={(e) => {
                                                                if (!confirm("¿Estás seguro de que deseas eliminar este empleado?")) {
                                                                    e.preventDefault();
                                                                }
                                                            }}
                                                        >
                                                            <i className="fas fa-trash-alt mr-1"></i> {/* Icono de papelera */}
                                                            Eliminar
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
