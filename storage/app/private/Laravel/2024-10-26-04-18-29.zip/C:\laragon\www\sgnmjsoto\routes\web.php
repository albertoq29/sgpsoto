<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmpleadoController;
use Inertia\Inertia;
use App\Http\Middleware\AdminMiddleware;
use App\Http\Controllers\BackupController;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Rutas de empleados
Route::middleware(['auth','admin'])->group(function () {
    Route::get('/empleados', [EmpleadoController::class, 'index'])->name('empleados.index'); // Vista de lista de empleados
    Route::get('/empleados/create', [EmpleadoController::class, 'create'])->name('empleados.create'); // Formulario de creación
    Route::post('/empleados', [EmpleadoController::class, 'store'])->name('empleados.store'); // Guardar nuevo empleado
    Route::get('/empleados/edit/{id}', [EmpleadoController::class, 'edit'])->name('empleados.edit'); // Formulario de edición
    Route::put('/empleados/update/{id}', [EmpleadoController::class, 'update'])->name('empleados.update'); // Actualizar empleado
    Route::delete('/empleados/{id}', [EmpleadoController::class, 'destroy'])->name('empleados.destroy'); // Eliminar empleado
});



Route::middleware(['auth'])->group(function () {
    Route::get('/backups', [BackupController::class, 'index'])->name('backups.index');
    Route::post('/backups/create', [BackupController::class, 'create'])->name('backups.create');
    Route::post('/backups/restore/{fileName}', [BackupController::class, 'restore'])->name('backups.restore');
});

require __DIR__.'/auth.php';
